from math import ceil

from django.contrib import messages
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.shortcuts import render, redirect
from django.core.mail import send_mail,EmailMultiAlternatives,BadHeaderError,EmailMessage,send_mass_mail
from django.core.mail import EmailMultiAlternatives
from .forms import Createuserform, contactform, feedbackform,ProductForm
from .models import Product, Orders,User
import json
from django.http import Http404,HttpResponse
from django.core.mail import EmailMultiAlternatives


# Create your views here.



def signup(request):
       form=Createuserform()
       if request.method=="POST":
          form = Createuserform(request.POST)
          if form.is_valid():
            user=form.cleaned_data.get('username')
            email=form.cleaned_data.get('email')

            send_mail("You Have Successfully Registered In Urent","Congratulations Mr "+ user+ " You have Successfully Registered To Urent Start Giving Your Items For Rent And Take Rent"
                                                                                                      "Thank You,Urent",email,['urent7890@gmail.com',email])
            messages.success(request, "Hi  "+user + " Your Account  Created Successfully We Sent A Email To Your Email")
            form.save()
            return redirect("loginpage")
          else:
              messages.warning(request,"You Have Entered Invalid Details")

       return render(request,"newapp/signup.html",{'form':form,'title':'reqister here'})


def loginpage(request):

      if request.method=="POST":
        username=request.POST.get('username')
        password=request.POST.get('password')

        user=authenticate(request,username=username,password=password)
        if user is not None:
            login(request,user)
            return redirect("homepage")
        else:
            messages.info(request,'Username or Password is incorrect')

      return render(request,"newapp/login.html")
def logoutpage(request):
    logout(request)
    return redirect("loginpage")


@login_required(login_url="loginpage")
def index(request):
    allProds = []
    catprods = Product.objects.values('category', 'id')
    cats = {item['category'] for item in catprods}
    for cat in cats:
        prod = Product.objects.filter(category=cat)
        n = len(prod)
        nSlides = n // 4 + ceil((n / 4) - (n // 4))
        allProds.append([prod, range(1, nSlides), nSlides])

    # params = {'no_of_slides':nSlides, 'range': range(1,nSlides),'product': products}
    # allProds = [[products, range(1, nSlides), nSlides],
    #             [products, range(1, nSlides), nSlides]]
    params = {'allProds': allProds}
    return render(request,"business/index.html",params)




def searchMatch(query, item):
    '''return true only if query matches the item'''
    if query in item.desc.lower() or query in item.itemname.lower()   or query in item.category.lower() or query in item.itemowner.lower() or query in item.adress  :
        return True
    else:
        return False
@login_required(login_url="loginpage")
def search(request):
    query = request.GET.get('search')
    allProds = []
    catprods = Product.objects.values('category', 'id')
    cats = {item['category'] for item in catprods}
    for cat in cats:
        prodtemp = Product.objects.filter(category=cat)
        prod = [item for item in prodtemp if searchMatch(query, item)]

        n = len(prod)
        nSlides = n // 4 + ceil((n / 4) - (n // 4))
        if len(prod) != 0:
            allProds.append([prod, range(1, nSlides), nSlides])
    params = {'allProds': allProds, "msg": ""}
    if len(allProds) == 0 or len(query)<3:
        params = {'msg': "Please make sure to enter relevant search query"}
    return render(request, 'business/search.html', params)
def terms(request):
    return render(request,"business/terms.html")

@login_required(login_url="loginpage")
def feedback(request):
    if request.method=="POST":
        form4=feedbackform(request.POST)
        if form4.is_valid():
            form4.save()
            name=form4.cleaned_data.get('name')
            feedback = form4.cleaned_data.get('feedback')
            email=form4.cleaned_data.get('email')
            messages.success(request,"Thank You "+ name +" For Giving Your Valuable Feedback we will Send An Email As Confirmation")
            send_mail(
                "We have Successfully received Your Feedback ",  # subject
                feedback+"        Tq u team Urent",  # message
                email,  # from email
                ['urent7890@gmail.com',email]# to Email
            )
            return redirect('feedback')

    else:
        form4=feedbackform()
    return render(request,"business/commentpage.html")

@login_required(login_url="loginpage")
def checkout(request):
    if request.method=="POST":
        items_json=request.POST.get('itemsJson','')
        name= request.POST.get('name','')
        useremail = request.POST.get('useremail', '')
        address1 = request.POST.get('address1', '')
        address2= request.POST.get('address2','')
        city = request.POST.get('city', '')
        state= request.POST.get('state', '')
        zip_code = request.POST.get('zip_code', '')
        phone = request.POST.get('phone', '')
        order=Orders(items_json=items_json,name=name,useremail=useremail,address1=address1,address2=address2,city=city,state=state,zip_code=zip_code,phone=phone)
        sum = len(items_json)
        if sum>2:
          order.save()
          thank = True
          id = order.order_id
          send_mail(
            "You Can Take Rent Now We Have Sent Your Adress,Contat Deatils To The Owner Successfully For Delivery Options Once Contact To The Item Owner,We Dont Offer delivery Options You Have To Pickup Your Item From Them And You have to submit Them  ",  # subject
            items_json + "  These Are Your Items And Your token No Is  "+str(id),  # message
            useremail,  # from email
            ['urent7890@gmail.com', useremail]  # to Email
           )
          return render(request,"business/checkout.html",{'thank':thank,'id':id})
        else:
           return HttpResponse("You Can Not take Rent Without Choosing Items,Kindly Choose any Items And Then Fill the Form")

    return render(request,"business/checkout.html")


@login_required(login_url="loginpage")
def contactpage(request):
    if request.method=="POST":
        form2=contactform(request.POST)
        if form2.is_valid:
            form2.save()
            name=form2.cleaned_data.get('name')
            desc=form2.cleaned_data.get('desc')
            email=form2.cleaned_data.get('email')

            # send email
            if name and desc and email:
              try:
               send_mail(
               "You  have Successfully submitted ur Query We Will look InTo Your Issue",# subject
               desc,# message
               email,#from email
               ["urent7890@gmail.com",email],#to Email
                )
               messages.success(request, "Thank You " + name + " We Have Received Your Query And   We Will send An Email For Confirmation")
              except BadHeaderError:
                 return BadHeaderError
            else:
                return Http404
            return redirect("contactpage")
    else:
        form2=contactform()
    return render(request,"business/contactpage.html",{'form2':form2})


@login_required(login_url="loginpage")
def itempage(request):
    users=User.objects.all()
    user= request.user
    if request.method=="POST":
         form1=ProductForm(request.POST,request.FILES)
         if form1.is_valid():
           itemowner=form1.cleaned_data.get('itemowner')
           category=form1.cleaned_data.get('category')
           itemname=form1.cleaned_data.get('itemname')
           itemrentperday=form1.cleaned_data.get('itemrentperday')
           adress=form1.cleaned_data.get('adress')
           whatasappno=form1.cleaned_data.get('whatsappno')
           whatasappno2=form1.cleaned_data.get('whatsappno2')
           desc=form1.cleaned_data.get('desc')
           global uemail
           uemail=form1.cleaned_data.get('uemail')
           send_mail(
               "You  have Successfully submitted Ur Item Deatails",  # subject
               "Details : "+
               "  Category : "+ category +
               "  Itemname : "+ itemname +
               "  Itemowner : "+ itemowner +
               "  Itemrentperday : "+ str(itemrentperday) +
               "  Adress : "+ str(adress) +
               "  Contact : "+ str(whatasappno) +
               "  Additional Mobile Number : "+ str(whatasappno2) +
               " IF YOU HAVE ENTERED WRONG DETAILS THEN YOU CAN EDIT IT IN THE MY ITEMS SECTION"


               ,  # message
               uemail,  # from email
               ["urent7890@gmail.com", uemail],  # to Email
           )
           doc = form1.save(commit=False)
           doc.user = request.user
           doc.save()
           messages.info(request, "Congratulations " +itemowner+" You Have Successfully Entered Your " +category +" with  deatils " + itemname+" We Have Sent A Confirmation Gmail To You once Check your Items In Gmail And In Myitems Section")
           return redirect("itempage")
         else:
          messages.info(request,"Your Form Is NOt Valid Please Enter Proper Deatils")
    else:
        form1=ProductForm()


    return render(request,"business/urcam.html",{'form1':form1})



@login_required(login_url="loginpage")

def prodview(request,myid):

    prod = Product.objects.filter(id=myid)
    #fetch the product using id
    return render(request,"business/prodview.html",{'prod':prod[0]})

@login_required(login_url="loginpage")
def myitems(request):
    users=User.objects.all()
    user=request.user
    ##url=("https://www.google.com/maps/embed/v1/MODE?key=&parameters")
    pros=Product.objects.filter(user=request.user)
    length=len(pros)
    return render(request,"business/myitems.html",{'pros':pros,'length':length})

@login_required(login_url="loginpage")

def aboutus(request):
    return render(request,"business/aboutus.html")

@login_required(login_url="loginpage")
def edit(request,id):
    users = User.objects.all()
    user = request.user
    pro=Product.objects.get(id=id)
    return render(request,'business/edit.html',{'pro':pro})

@login_required(login_url="loginpage")
def update(request,id):
    pro=Product.objects.get(id=id)
    form1=ProductForm(request.POST,request.FILES,instance=pro)
    if form1.is_valid():
        form1.save()
        return redirect("/myitems")
    else:
        form1=ProductForm()
        print("Wrong Deatils")
    return render(request,'business/edit.html',{'pro':pro})

@login_required(login_url="loginpage")
def destroy(request,id):
    pro=Product.objects.get(id=id)
    pro.delete()
    return redirect("myitems")
    return render(request,"business/edit.html")




